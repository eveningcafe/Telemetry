#!/bin/bash

sudo -E copy_file.sh

#Check CEILOMETER_START Env variable
if [ -z ${CEILOMETER_START+x} ]; then
  echo "ENV START_CEILOMETER is unset"
  /bin/bash
elif [ "$CEILOMETER_START" = "START_CEILOMETER_AGENT_COMPUTE" ]; then
  #/usr/bin/ceilometer-polling --config-file=/etc/ceilometer/ceilometer.conf --polling-namespaces compute --log-file=/var/log/ceilometer/ceilometer-agent-compute.log
  service ceilometer-agent-compute start && tail -F /var/log/lastlog
elif [ "$CEILOMETER_START" = "START_CEILOMETER_AGENT_IPMI" ]; then
  service ceilometer-agent-ipmi start && tail -F /var/log/lastlog
else
 echo "CEILOMETER_START is set to '$CEILOMETER_START'"
fi
