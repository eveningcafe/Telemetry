#!/bin/bash

sudo -E copy_file.sh

#Check CEILOMETER_START Env variable
if [ -z ${CEILOMETER_START+x} ]; then
  echo "ENV START_CEILOMETER is unset"
  /bin/bash
elif [ "$CEILOMETER_START" = "BOOTSTRAP" ]; then
  ceilometer-upgrade --skip-metering-database
elif [ "$CEILOMETER_START" = "UPGRADE" ]; then
  #if UPGRADE
  ceilometer-upgrade --skip-metering-database
elif [ "$CEILOMETER_START" = "START_CEILOMETER_AGENT_CENTRAL" ]; then
  service ceilometer-agent-central start && tail -F /var/log/lastlog
elif [ "$CEILOMETER_START" = "START_CEILOMETER_AGENT_NOTIFICATION" ]; then
  service ceilometer-agent-notification start && tail -F /var/log/lastlog
else
 echo "CEILOMETER_START is set to '$CEILOMETER_START'"
fi
